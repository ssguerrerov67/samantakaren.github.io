# Pagina realizada para mantener mi Curriculum Vitae 

## ¿Quien Soy?

Soy un apasionado por: 
* mi familia
* los viajes
* las nuevas experiencias
* los deportes
* la tecnologia
* los vinos

## ¿Apasionado de los deportes?

Si, He realizado Triatlones, Media Maratones, Cruce a Nado el Rio Orinoco y Caroni en 2017, he subido y acampado en los picos mas altos de mi querido cerro Avila,
he escalado el pico Toro en Merida Venezuela 4755 mts sobre el nivel del mar, asi como el Roraima Tepuy.
Cruce Argentina en bicicleta por la ruta 23, provincia de Rio Negro desde la coordillera al mar, 650 Kms en 4 dias, en diciembre de 2023.

## ¿Apasionado de la tecnologia?

Solo en los ultimos 5 años he realizado mas de 45 cursos en la plataforma Udemy.

## ¿Apasionado de los Vinos?

Me encanta un buen vino, he visitado bodegas en Italia en la Toscana, asi como en Argentina en Mendoza y Cordoba, cada vez que viajo trato de probar vinos de 
diferentes lugares del mundo.
 
